package com.freeup.app

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

const val FREE_LIMIT_BYTES = 1L * 1024 * 1024 * 1024   // free tier: 1 GB per run (wire to Play Billing later)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { FreeUpScreen() } } }
    }
}

fun fmt(b: Long): String = if (b >= 1L shl 30) "%.2f GB".format(b / 1073741824.0) else "%.1f MB".format(b / 1048576.0)

@Composable
fun FreeUpScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var months by remember { mutableIntStateOf(12) }
    var videosOnly by remember { mutableStateOf(true) }
    var items by remember { mutableStateOf(listOf<Item>()) }
    var selected by remember { mutableStateOf(setOf<Uri>()) }
    var dest by remember { mutableStateOf<Uri?>(null) }
    var verified by remember { mutableStateOf(listOf<Item>()) }
    var status by remember { mutableStateOf("Tap Scan to find old photos and videos.") }
    var busy by remember { mutableStateOf(false) }
    val isPremium = false // TODO: set from Google Play Billing

    fun doScan() = scope.launch {
        busy = true; status = "Scanning..."
        items = withContext(Dispatchers.IO) { scan(ctx, months, videosOnly) }
        selected = emptySet(); verified = emptyList()
        status = "Found ${items.size} items (${fmt(items.sumOf { it.size })})."
        busy = false
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r.values.any { it }) doScan() else status = "Permission denied. FreeUp needs photo/video access to scan your library."
    }
    val folderLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            ctx.contentResolver.takePersistableUriPermission(uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            dest = uri; status = "Destination set."
        }
    }
    val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (r.resultCode == android.app.Activity.RESULT_OK) {
            status = "Freed ${fmt(verified.sumOf { it.size })}. Empty the Trash/Recently deleted in your gallery if space does not update."
            items = items.filter { it !in verified }; verified = emptyList(); selected = emptySet()
        } else status = "Delete cancelled. Your originals are untouched."
    }

    Column(Modifier.padding(16.dp).fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("FreeUp", style = MaterialTheme.typography.headlineMedium)
        Text("Copy to your drive, verify, then delete. Nothing leaves your phone.", style = MaterialTheme.typography.bodyMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            listOf(6, 12, 24).forEach { m ->
                FilterChip(selected = months == m, onClick = { months = m }, label = { Text("> $m mo") })
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(videosOnly, { videosOnly = it }); Spacer(Modifier.width(8.dp)); Text("Videos only (frees most space)")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = !busy, onClick = {
                val p = if (Build.VERSION.SDK_INT >= 33)
                    arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
                else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
                permLauncher.launch(p)
            }) { Text("Scan") }
            OutlinedButton(enabled = !busy, onClick = { folderLauncher.launch(null) }) {
                Text(if (dest == null) "Choose drive folder" else "Change folder")
            }
        }
        val chosen = items.filter { it.uri in selected }
        val chosenSize = chosen.sumOf { it.size }
        Button(enabled = !busy && dest != null && chosen.isNotEmpty(), onClick = {
            if (!isPremium && chosenSize > FREE_LIMIT_BYTES) {
                status = "Free limit is 1 GB per run. Select less, or upgrade."
            } else scope.launch {
                busy = true
                val dir = DocumentFile.fromTreeUri(ctx, dest!!)
                if (dir == null || !dir.canWrite()) { status = "Cannot write to that folder. Is the drive connected?"; busy = false; return@launch }
                val ok = mutableListOf<Item>()
                chosen.forEachIndexed { i, it ->
                    status = "Copying & verifying ${i + 1}/${chosen.size}: ${it.name}"
                    if (withContext(Dispatchers.IO) { copyAndVerify(ctx, it, dir) }) ok += it
                }
                verified = ok
                status = "Verified ${ok.size} of ${chosen.size}. ${if (ok.isNotEmpty()) "Safe to delete originals." else "Nothing deleted."}"
                busy = false
            }
        }) { Text("Copy & verify (${chosen.size} items, ${fmt(chosenSize)})") }
        Button(enabled = !busy && verified.isNotEmpty(), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
            onClick = {
                val pi = MediaStore.createDeleteRequest(ctx.contentResolver, verified.map { it.uri })
                deleteLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
            }) { Text("Delete ${verified.size} verified originals") }
        Text(status, style = MaterialTheme.typography.bodyMedium)
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        LazyColumn(Modifier.weight(1f)) {
            items(items, key = { it.uri.toString() }) { it ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(it.uri in selected, { c -> selected = if (c) selected + it.uri else selected - it.uri })
                    Column { Text(it.name, maxLines = 1); Text("${if (it.video) "Video" else "Photo"} · ${fmt(it.size)}", style = MaterialTheme.typography.bodySmall) }
                }
            }
        }
    }
}
